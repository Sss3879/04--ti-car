################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ICM42688/icm42688.c 

C_DEPS += \
./ICM42688/icm42688.d 

OBJS += \
./ICM42688/icm42688.o 

OBJS__QUOTED += \
"ICM42688\icm42688.o" 

C_DEPS__QUOTED += \
"ICM42688\icm42688.d" 

C_SRCS__QUOTED += \
"../ICM42688/icm42688.c" 


